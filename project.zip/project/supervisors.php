
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" type="text/css" href="styles.css">
<div class="small-top">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 date-sec">
        <div id="Date"></div>
      </div>
            <div class="col-lg-3 offset-lg-5">
        <div class="social-icon"> <a target="_blank" href="#" class=" fa fa-facebook"></a> <a target="_blank" href="#" class=" fa fa-twitter"></a> <a target="_blank" href="#" class=" fa fa-google-plus"></a> <a target="_blank" href="#" class=" fa fa-linkedin"></a> <a target="_blank" href="#" class=" fa fa-youtube"></a> <a target="_blank" href="#" class=" fa fa-vimeo-square"></a> </div>
      </div>
      </div>
          </div>
  </div>
        <div class="top-head left">
    <div class="container">
            <div class="row">
        <div class="col-md-6 col-lg-4">
                <h1>My Profile<small>Get the latest Jobs</small></h1>
              </div>
        <div class="col-md-6 col-lg-3 ml-auto admin-bar hidden-sm-down">
                <nav class="nav nav-inline"> <a href="#" class="nav-link"><span class="ping"></span><i class="fa fa-envelope-o"></i></a> <a href="#" class="nav-link"><i class="fa fa-bell-o"></i></a> 
                	<?php 
                	require('connection.php');
						session_start();

						if(!isset($_SESSION['username'])){

							header("location:login_form1.php");

								}
								$username=$_SESSION['username'];
                	echo "<a href='#' class='nav-link'>$username<img class='img-fluid rounded-circle' src='http://grafreez.com/wp-content/temp_demos/river/img/admin-bg.jpg'>";?>
                	</a> 
                </nav>
              </div>
      </div>
          </div>
  </div>
      </header>
<section class="top-nav">
    <nav class="navbar navbar-expand-lg py-0">
        <div class="container">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="exCollapsingNavbar2">
            <ul class="nav navbar-nav ">
        <li class="nav-item active"> <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
        <li class="nav-item"> <a class="nav-link" href="supervisors.php">My Profile</a> </li>
        
        <li class="nav-item"> <a class="nav-link" href="add_form.php">Add Job</a> </li>
         <li class="nav-item"> <a class="nav-link" href="logout.php">Logout</a> </li>
      </ul>
            <form class="ml-auto">
        <div class="search">
                <input type="text" class="form-control" maxlength="64" placeholder="Search" />
                <button type="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
              </div>
              
      </form>
     
          </div>
  </div>
      </nav>
</section>
    <?php

//require('sup_bar.htm');

require('connection.php');

$username=$_SESSION['username'];
$query="Select * from register where username='$username'";
$result=mysqli_query($conn,$query);
  foreach ($result as $user) {

$query = "select * from Add_Job where UserFK=".$user['ID']." ORDER BY DateTime DESC";
$result = mysqli_query($conn,$query);

echo " <div class='section'>
    <div class='container'>
 <h1>My Jobs</h1>
        <div class='row'>   ";
	foreach ($result as $job) {

               
       echo" <div class='col-md-3'>
                <a href='details.php?id=".$job['ID'] . "'>
                 <div class='card'> <img class='img-fluid' src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwp1q11eLnFrde0uXFyCWGPmUkZkhT7wNmln7-hjjBP5hoHRg8bA' alt=''>
                <div class='card-img-overlay'> <span class='badge badge-pill badge-danger'>Job</span> </div>
                <div class='card-body'>
            <div class='news-title'>
              <h5 class='card-title'>".$job['JobTitle']."</h5>
                    <h2 class='title-small'><a href='#'>".$job['JobDescription']."</a></h2>
                  </div>
            <p class='card-text'><small class='text-time'><em>".$job['DateTime']."</em></small></p>
          </div>
              </div></a>
                  
            </div>";
          
   

	
	}
}


?>
</div></div></div>

</body>
</html>
