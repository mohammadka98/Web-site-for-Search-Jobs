<?php
require('connection.php');
session_start();
if(isset($_GET['submit'])){
if(!isset($_SESSION['username'])){

header("location:login_form1.htm");

}
$username=$_SESSION['username'];
$query="Select * from register where username='$username'";
$result=mysqli_query($conn,$query);
  foreach ($result as $user) {



$job_title = $_GET['job_title'];
$company_name = $_GET['company_name'];
$category = $_GET['category'];
$address = $_GET['address'];
$street = $_GET['street'];
$city = $_GET['city'];
$job_description = $_GET['job_description'];
$job_requirements = $_GET['job_requirements'];
$salary = $_GET['salary'];
$tele_no = $_GET['tele_no'];
$email = $_GET['email'];
$userFK=$user['ID'];

$query1 = "insert into Add_Job (JobTitle, CompanyName, Category, Address, Street, City, JobDescription, JobRequirements, Salary, TeleNo, Email,UserFK) values ('$job_title', '$company_name', '$category', '$address', '$street', '$city',
 '$job_description', '$job_requirements', $salary, $tele_no,'$email',$userFK)";

$result1 = mysqli_query($conn,$query1);

if($result1){

header("location:supervisors.php");
}else{

	header("location:add_job.php");
	echo "NO data submitted";
}
}
}

?>
