
<?php

	$localhost = "localhost";
	$username = "root";
	$password = "";
	$db_name = "myjob";

	$conn = mysqli_connect($localhost, $username, $password, $db_name);

	if(!$conn){

		die("can't access to the server" . mysqli_error());
	}

?>