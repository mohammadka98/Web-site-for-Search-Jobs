<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" type="text/css" href="styles.css">
<div class="small-top">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 date-sec">
        <div id="Date"></div>
      </div>
            <div class="col-lg-3 offset-lg-5">
        <div class="social-icon"> <a target="_blank" href="#" class=" fa fa-facebook"></a> <a target="_blank" href="#" class=" fa fa-twitter"></a> <a target="_blank" href="#" class=" fa fa-google-plus"></a> <a target="_blank" href="#" class=" fa fa-linkedin"></a> <a target="_blank" href="#" class=" fa fa-youtube"></a> <a target="_blank" href="#" class=" fa fa-vimeo-square"></a> </div>
      </div>
      </div>
          </div>
  </div>
        <div class="top-head left">
    <div class="container">
            <div class="row">
        <div class="col-md-6 col-lg-4">
                <h1>My Profile<small>Get the latest Jobs</small></h1>
              </div>
        <div class="col-md-6 col-lg-3 ml-auto admin-bar hidden-sm-down">
                <nav class="nav nav-inline"> <a href="#" class="nav-link"><span class="ping"></span><i class="fa fa-envelope-o"></i></a> <a href="#" class="nav-link"><i class="fa fa-bell-o"></i></a> 
                    <?php 
                    require('connection.php');
                        session_start();

                        if(!isset($_SESSION['username'])){

                            header("location:login_form1.php");

                                }
                                $username=$_SESSION['username'];
                    echo "<a href='#' class='nav-link'>$username<img class='img-fluid rounded-circle' src='http://grafreez.com/wp-content/temp_demos/river/img/admin-bg.jpg'>";?>
                    </a> 
                </nav>
              </div>
      </div>
          </div>
  </div>
      </header>
<section class="top-nav">
    <nav class="navbar navbar-expand-lg py-0">
        <div class="container">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="exCollapsingNavbar2">
            <ul class="nav navbar-nav ">
        <li class="nav-item active"> <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
        <li class="nav-item"> <a class="nav-link" href="supervisors.php">My Profile</a> </li>
        
        <li class="nav-item"> <a class="nav-link" href="add_form.php">Add Job</a> </li>
         <li class="nav-item"> <a class="nav-link" href="logout.php">Logout</a> </li>
      </ul>
         
     
          </div>
  </div>
      </nav>
</section>
<?php


if(!isset($_SESSION['username'])){

header("location:login_form1.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="style1.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

    <link href="https://fonts.googleapis.com/css?family=Oleo+Script:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Teko:400,700" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<section id="contact">
            <div class="section-content">
                <h1 class="section-header">Get in <span class="content-header wow fadeIn " data-wow-delay="0.2s" data-wow-duration="2s"> Your Job</span></h1>
                <h3>all Input are Required</h3>
            </div>
            <div class="contact-section">
            <div class="container">
                <form form action="add_job.php" method="get">
                    <div class="col-md-6 form-line">
                        <div class="form-group">
                            <label for="exampleInputUsername">Job Name</label>
                            <input type="text" name="job_title" class="form-control" id="" placeholder=" Enter Name">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail">Company Name</label>
                            <input type="text" name="company_name" class="form-control" id="exampleInputEmail" placeholder=" Enter Company Name">
                        </div>  
                        <div class="form-group">
                            <label for="telephone">Category</label>
                            <input type="text" name="category" class="form-control" id="telephone" placeholder=" Enter Category">
                        </div>
                         <div class="form-group">
                            <label for="Address">Address</label>
                            <input type="text" name="address" class="form-control" id="telephone" placeholder=" Enter Address">
                        </div>
                         <div class="form-group">
                            <label for="telephone">Street</label>
                            <input type="text" name="street" class="form-control" id="telephone" placeholder=" Enter Street">
                        </div>
                         <div class="form-group">
                            <label for="telephone">City</label>
                            <input type="city" name="city" class="form-control" id="telephone" placeholder=" Enter City">
                        </div>
                    </div>
                    <div class="col-md-6" style="margin-bottom: 60px;">
                        <div class="form-group">
                            <label for ="description"> Job Description</label>
                            <textarea name="job_description" class="form-control" id="description" placeholder="Enter Job Description"></textarea>
                        </div>
                        <div class="form-group">
                            <label for ="description"> Job Requirements</label>
                            <textarea name="job_requirements" class="form-control" id="description" placeholder="Enter Job Requirements"></textarea>
                        </div>
                          <div class="form-group">
                            <label for="salary">Salary</label>
                            <input type="city" name="salary" class="form-control" id="salary" placeholder=" Enter City">
                        </div>
                          <div class="form-group">
                            <label for="telephone">Phone Number</label>
                            <input type="city" name="tele_no" class="form-control" id="telephone" placeholder=" Enter City">
                        </div>
                          <div class="form-group">
                            <label for="Email">Email</label>
                            <input type="city" name="email" class="form-control" id="telephone" placeholder=" Enter City">
                        </div>
                        <div >

                            <button type="submit" class="btn btn-default submit"
                            name="submit" >Save</button>
                        </div>
                        
                    </div>
                </form>
            </div>
        </section>
</body>
</html>

  
