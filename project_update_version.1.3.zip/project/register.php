<?php

require('connection.php');

if(isset($_POST['submit'])){

$username = $_POST['username'];
$password = $_POST['password'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$email = $_POST['email'];



$query = "insert into register (UserName, Password, TeleNo, Address, Email) values 
                               ('$username','$password', $phone, '$address','$email')";

$result = mysqli_query($conn, $query);

header("location:login_form1.php");

}
else{

	header("location:register_form1.htm");
	echo "NO data submitted";

}


?>