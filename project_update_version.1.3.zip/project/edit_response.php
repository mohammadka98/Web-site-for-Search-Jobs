<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LandMarks</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/simple-sidebar.css" rel="stylesheet">

</head>
<style type="text/css">
	img{float: left; height: 300PX;width: 370PX; margin:8PX;  }
	li div{ clear: both; font-size:  20px; font-family: sans-serif ;}
	p{margin-top: 20px;}
	h1{margin-left: 50px;  }
	body{background-image: url(" https://mdbootstrap.com/img/Photos/Others/background.jpg");}
</style>
<body >
 
        <div id="page-content-wrapper">
            <div class="container-fluid">
                
               <?php
require('connection.php');
   if(!isset($_SESSION['username']))
                {
                    header("location:login_form1.php");
                }
$ID=$_GET['ID'];
$Name=$_GET['job_title'];
$company_name=$_GET['company_name'];
$category=$_GET['category'];
$address=$_GET['address'];
$street=$_GET['street'];
$city=$_GET['city'];
$job_description=$_GET['job_description'];
$job_requirements=$_GET['job_requirements'];
$salary=$_GET['salary'];
$tele_no=$_GET['tele_no'];
$email=$_GET['email'];
$query="update Add_Job set JobTitle='$Name',CompanyName='$company_name',Category='$category',Address='$address',Street='$street' ,City='$city' ,JobDescription='$job_description' ,JobRequirements='$job_requirements' ,Salary=$salary ,Tele_no=$tele_no ,Email='$email'  where ID=$ID";
$result=mysqli_query($conn,$query);
if($result)
{
require('supervisors.php');
}
else{echo require('supervisors.php');}

                ?>
              
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Bootstrap core JavaScript -->

   

</body>

</html>