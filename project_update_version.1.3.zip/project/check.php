<?php
session_start();
require('connection.php');

$username = $_POST['username'];
$password = $_POST['password'];

$query = "select * from register where username = '$username' and password = '$password'";

$result = mysqli_query($conn, $query);

$num = mysqli_num_rows($result);

if($num>=1){
$_SESSION['username'] = $username;
//setcookie("username",$username,time() + 86400);
header("location:index.php");

}else{echo "Invalid username or password!!";}


?>