
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="css/styles_details.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>eCommerce Product Detail</title>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="styles.css">
  </head>

  <body>

<div class="small-top">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 date-sec">
        <div id="Date"></div>
      </div>
            <div class="col-lg-3 offset-lg-5">
        <div class="social-icon"> <a target="_blank" href="#" class=" fa fa-facebook"></a> <a target="_blank" href="#" class=" fa fa-twitter"></a> <a target="_blank" href="#" class=" fa fa-google-plus"></a> <a target="_blank" href="#" class=" fa fa-linkedin"></a> <a target="_blank" href="#" class=" fa fa-youtube"></a> <a target="_blank" href="#" class=" fa fa-vimeo-square"></a> </div>
      </div>
      </div>
          </div>
  </div>
        <div class="top-head left">
    <div class="container">
            <div class="row">
        <div class="col-md-6 col-lg-4">
                <h1>My Profile<small>Get the latest Jobs</small></h1>
              </div>
        <div class="col-md-6 col-lg-3 ml-auto admin-bar hidden-sm-down">
                <nav class="nav nav-inline"> <a href="#" class="nav-link"><span class="ping"></span><i class="fa fa-envelope-o"></i></a> <a href="#" class="nav-link"><i class="fa fa-bell-o"></i></a> 
                    <?php 
                    require('connection.php');
                        session_start();

                        if(!isset($_SESSION['username'])){

                            header("location:login_form1.php");

                                }
                                $username=$_SESSION['username'];
                    echo "<a href='#' class='nav-link'>$username<img class='img-fluid rounded-circle' src='http://grafreez.com/wp-content/temp_demos/river/img/admin-bg.jpg'>";?>
                    </a> 
                </nav>
              </div>
      </div>
          </div>
  </div>
      </header>
<section class="top-nav">
    <nav class="navbar navbar-expand-lg py-0">
        <div class="container">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="exCollapsingNavbar2">
            <ul class="nav navbar-nav ">
        <li class="nav-item active"> <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
         <li class="nav-item"> <a class="nav-link" href="TopSixJobs.php">Top</a> </li>
        <li class="nav-item"> <a class="nav-link" href="supervisors.php">My Profile</a> </li>
        
        <li class="nav-item"> <a class="nav-link" href="add_form.php">Add Job</a> </li>
         <li class="nav-item"> <a class="nav-link" href="logout.php">Logout</a> </li>
      </ul>
            <form class="ml-auto">
        <div class="search">
                <input type="text" class="form-control" maxlength="64" placeholder="Search" />
                <button type="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
              </div>
              
      </form>
     
          </div>
  </div>
      </nav>
</section>
 <div class="container">
        <div class="card">
            <div class="container-fliud">
                <div class="wrapper row">
                    <div class="preview col-md-6">
                         <div class="preview-pic tab-content">
                            <?php
   require('connection.php');

    if(isset($_GET['id'])){

        $id = $_GET['id'];

    $query = "select * from Add_Job where id = $id";

    $result = mysqli_query($conn,$query);


    foreach ($result as $job) {

                       
                    echo"  <div class='tab-pane active' id='pic-1'><img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwp1q11eLnFrde0uXFyCWGPmUkZkhT7wNmln7-hjjBP5hoHRg8bA' /></div>
                        <div class='rating'>
                            <div class='stars'>
                                <span class='fa fa-star checked'></span>
                                <span class='fa fa-star checked'></span>
                                <span class='fa fa-star checked'></span>
                                <span class='fa fa-star'></span>
                                <span class='fa fa-star'></span>
                            </div>
                            <span class='review-no'>41 reviews</span>
                        </div>
                          <h3 >
          
                  <a href='http://localhost/project/edit.php?id=".$job['ID']."><button class='btn btn-default' style='background-color:#E65100;'>Edit</button></a>
                  <a href='http://localhost/project/delete.php?id=".$job['ID']."> <button class='btn btn-default' style='background-color:#FFAB40;'>Delete</button></a>
                 
                        </h3>
                        </div>
                  
                        
                    </div>
                    <div class='details col-md-6'>
                    <h3 class='product-title' style='color:#D50000;'>".$job['JobTitle']."</h3>
                 <h5 class='product-title'>Company Name:  ".$job['CompanyName']."</h5>
        <h6 class='price'>current Salary: <span>".$job['Salary']."</span></h6>
        <h6  class='product-description'>Category: ".$job['Category']."</h6>
        <h6  class='product-description'>Address: ".$job['Address']."</h6>
        <h6  class='product-description'>City : ".$job['City']." - Street: ".$job['Street']."</h6>      
            <h6  class='product-description'>Telephone Number: ".$job['TeleNo']."</h6>
            <h6  class='product-description'>Email : ".$job['Email']."</h6>
             <h6  class='product-description'>Job Description: ".$job['JobDescription']."</h6>
             <h6  class='product-description'>Job Requirements: ".$job['JobRequirements']."</h6>

                       
                           ";
                   
               
     
          
   

    
    }
}else{

    header("location:index.php");
}


?>
    
                    </div>
                </div>
            </div>
        </div>
    </div>

            </div>"
</body>
</html>




    
   

