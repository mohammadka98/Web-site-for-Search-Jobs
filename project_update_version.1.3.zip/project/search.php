
<!DOCTYPE html>
<html>
<head>
  <title>Jobs</title>
</head>
<body>

</body>
</html>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" type="text/css" href="styles.css">
<div class="small-top">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 date-sec">
        <div id="Date"></div>
      </div>
            <div class="col-lg-3 offset-lg-5">
        <div class="social-icon"> <a target="_blank" href="#" class=" fa fa-facebook"></a> <a target="_blank" href="#" class=" fa fa-twitter"></a> <a target="_blank" href="#" class=" fa fa-google-plus"></a> <a target="_blank" href="#" class=" fa fa-linkedin"></a> <a target="_blank" href="#" class=" fa fa-youtube"></a> <a target="_blank" href="#" class=" fa fa-vimeo-square"></a> </div>
      </div>
      </div>
          </div>
  </div>
        <div class="top-head left">
    <div class="container">
            <div class="row">
        <div class="col-md-6 col-lg-4"> 
                <h1>Jobs<small>Get the latest Jobs</small></h1>
              </div>
        <div class="col-md-6 col-lg-3 ml-auto admin-bar hidden-sm-down">
                <nav class="nav nav-inline"> <a href="#" class="nav-link"><span class="ping"></span><i class="fa fa-envelope-o"></i></a> <a href="#" class="nav-link"><i class="fa fa-bell-o"></i></a> </a> 
                  <?php 
                  require('connection.php');
            session_start();

            if(isset($_SESSION['username']))
                $username=$_SESSION['username'];
                  echo "<a href='#' class='nav-link'>$username<img class='img-fluid rounded-circle' src='http://grafreez.com/wp-content/temp_demos/river/img/admin-bg.jpg'>";?>
                  </a>  </nav>
              </div>
      </div>
          </div>
  </div>
      </header>
<section class="top-nav">
    <nav class="navbar navbar-expand-lg py-0">
        <div class="container">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="exCollapsingNavbar2">
            <ul class="nav navbar-nav ">
        <li class="nav-item active"> <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
         <li class="nav-item"> <a class="nav-link" href="TopSixJobs.php">Top</a> </li>
        <li class="nav-item"> <a class="nav-link" href="supervisors.php">My Profile</a> </li>

        <?php
        if(isset($_SESSION['username']))
 {
         echo "<li class='nav-item'> <a class='nav-link' href='logout.php'>Logout</a> </li>";
       }else{
        echo "<li class='nav-item'> <a class='nav-link' href='login_form1.php'>Login</a> </li>";
       }

         ?>
       
      </ul>
            <form class="ml-auto" action="search.php" method="post">
        <div class="search">
          <form >
                <input type="text" name="search" class="form-control" maxlength="64" placeholder="Search" />
                <button type="submit" name="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
              </form>
              </div>
             
      </form>
          </div>
  </div>
      </nav>
</section>
<section class="banner-sec">
        <div class="container">
    <div class="row">
<?php
require('connection.php');
if(isset($_POST['submit'])){
$name=$_POST['search'];
$query="Select * from Add_Job where JobTitle LIKE '%$name%'";
$result=mysqli_query($conn,$query);
  foreach ($result as $job)   
  {
       echo" <div class='col-md-3'>
                <a href='details.php?id=".$job['ID'] . "'>
                 <div class='card'> <img class='img-fluid' src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwp1q11eLnFrde0uXFyCWGPmUkZkhT7wNmln7-hjjBP5hoHRg8bA' alt=''>
                <div class='card-img-overlay'> <span class='badge badge-pill badge-danger'>Job</span> </div>
                <div class='card-body'>
            <div class='news-title'>
              <h5 class='card-title'>".$job['JobTitle']."</h5>
                    <h2 class='title-small'><a href='#'>".$job['JobDescription']."</a></h2>
                  </div>
            <p class='card-text'><small class='text-time'><em>".$job['DateTime']."</em></small></p>
          </div>
              </div></a>
                  
            </div>";  
            }   
  }
?>
      <section class="action-sec">
          <div class="container">
              <div class="action-box text-center"><h2>GET FULL JOBS HERE</h2><a class="btn btn-success" href="#" target="_blank">Created by Mohammad Arameen & Mohammad Al-Butmha  </a></div>
          </div>
      </section>
      
<script src="demo_script_src.js">
</script>
      
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</html>
